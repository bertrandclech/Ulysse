IMPORTANT
=========

The tool requires a Last Backup of Ulysse content. So be sure to first create one using UlysseApp -> Preferences -> Backups


