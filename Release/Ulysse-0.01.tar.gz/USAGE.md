Usage
=====

##AIM OF THE TOOL

This tool creates a full layout of Ulysse notes in markdown format.
It uses the Last Backup performed by Ulysse on user request see UlysseApp Preferences -> Backups

##LIMITATIONS

he tool do not deal with several Last Backup ... should not occur
